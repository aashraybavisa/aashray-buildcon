# Aashray Buildcon — Design System

Design system for **Aashray Buildcon**, a general-contractor / construction company based in **Rajkot, Gujarat**. It powers the company's marketing + lead-generation website (built with Expo + expo-router, deployed as a static site) and any future collateral.

The brand voice is **confident and professional** — an established builder that is on-time, on-budget and safety-first. The visual system pairs **safety amber** with **graphite/charcoal** for a grounded, "builder" feel.

## Sources
- **Codebase:** local Expo project `aashray-buildcon` (`create-expo-app` scaffold; expo-router file routing under `src/app/`). At the time of authoring the app was still the starter scaffold — no product UI was built — so this system is derived from the project's `PLAN.md` (sitemap, page content, and the §5 Design System brief) plus the scaffold's `src/constants/theme.ts` spacing/colour tokens and `src/global.css` font stack.
- **Brand inputs from the user:** company name + city (Aashray Buildcon, Rajkot); amber-on-charcoal accent direction (chosen from the plan's two options); light + dark; confident-professional tone. No logo file was supplied — the logo in this system is an **original mark designed in-house** (see Brand · Logo) and approved by the user.

---

## Content fundamentals
- **Tone:** confident, plain-spoken, trust-building. Speaks as "we" to the client ("you"). No hype, no jargon.
- **Casing:** Title Case for headings and buttons; sentence case for body and form labels. Eyebrows are UPPERCASE with wide tracking.
- **Copy patterns:** benefit-led and concrete — "On time. On budget." / "Building Rajkot's future, one project at a time." / "Snag-free handover with warranty." Numbers are used sparingly as proof (years, projects, sq-ft, on-time %).
- **CTAs:** action + outcome — "Request a Quote", "View Projects", "Send request". One primary action per view.
- **Currency / locale:** Indian — ₹ with L/Cr ranges ("Under ₹25L", "₹25L – ₹1Cr"), phone as `+91 …`.
- **Emoji:** not part of the brand voice in copy. (Emoji currently stand in for service icons in the UI kit — placeholders to be replaced with a real icon set, see Iconography.)

---

## Visual foundations
- **Colour:** one brand hue — **safety amber `#F4A300`** (hover `#D98E00`, press `#B87700`) — over a **graphite/charcoal** neutral ramp (ink `#1F2429`, near-black `#14181B`). White/`#F6F7F8` for light surfaces. Amber is used with restraint: CTAs, the mark, small accents, stat suffixes, active states. Status: success `#2E9E5B`, danger `#D64545`, info `#208AEF` (info doubles as the "Commercial" category tone).
- **Text on amber is always dark** (`#14181B`) — amber is a light colour; never white text on amber.
- **Typography:** **Spline Sans** for display/headings (700/600, tight tracking `-0.02em`, balanced wrapping); **Inter** for body/UI (400–600). Hero 56px; H1 40; H2 32; body 16–18; eyebrow 12 uppercase `0.12em`.
- **Spacing:** 4-based scale mirroring the codebase (`4/8/12/16/24/32/48/64/96`). Generous section padding (~88px vertical) on the web.
- **Radii:** cards 16px, controls 10px, tiles/logo 14px, pills 999. Corners are soft but not bubbly.
- **Elevation:** low, cool shadows (`shadow-sm/md/lg`); an amber glow (`shadow-accent`) only under primary buttons. Cards = white surface + 1px `--border` + `shadow-sm`, lifting to `shadow-lg` + amber border on hover (translateY(-4px)).
- **Backgrounds:** solid — white, `--surface-raised` (#F6F7F8), and full-bleed **charcoal bands** for hero / CTA / section intros. No gradients as decoration (one faint amber circle motif appears on charcoal CTA bands). Photography sits in rounded frames; a diagonal charcoal hatch is the image placeholder.
- **Motion:** quick and functional — 120–200ms, `ease-standard`/`ease-out`. Buttons nudge down 1px on press; cards translateY up on hover; project covers scale 1.05 on hover. No bounce.
- **Layout:** max content width 1200px, 32px gutters; 3-up grids for services/projects, 4-up for stats/process.
- **Dark mode:** full semantic dark theme via `[data-theme="dark"]` / `.theme-dark` — surfaces invert to graphite, borders lighten, amber stays the accent.

---

## Iconography
- **No icon set ships in the codebase.** Recommended substitute: **[Lucide](https://lucide.dev)** (outline, ~2px stroke) — it matches the monoline construction feel of the logo and the system's rounded joins. Load from CDN (`https://unpkg.com/lucide@latest`) and colour via `currentColor`. **Flag:** this is a substitution, not a brand-owned set — confirm or swap.
- **Service/category icons** in the UI kit currently use **emoji as placeholders** (🏠 🏢 🛠️). Replace with Lucide glyphs (e.g. `home`, `building-2`, `hammer`, `layout`, `ruler`, `wrench`) before production.
- **The logo mark** is the one bespoke glyph — an amber house/"A" (roof + doorway) in a charcoal tile. Assets in `assets/` (full-colour, amber, mono, outline, bare, favicon). Use `logo-mark-mono.svg` / `logo-tile-mono.svg` (`currentColor`) for single-ink / stamp use.
- No unicode-as-icon except the star `★` for ratings and `✓` for checklist ticks.

---

## Index / manifest
- **`styles.css`** — entry point; `@import`s everything below. Consumers link this one file.
- **`tokens/`** — `colors.css`, `typography.css`, `spacing.css` (radii/shadows/motion/layout), `fonts.css` (Spline Sans + Inter via Google Fonts — **substituted**, no local binaries supplied), `base.css`.
- **`assets/`** — logo suite + `favicon.svg`.
- **`guidelines/`** — foundation specimen cards (Colors, Type, Spacing, Brand).
- **`components/`** — reusable primitives:
  - `core/` — **Button**, **Badge**, **SectionHeading**, **StatCard**
  - `forms/` — **FormField** (input / textarea / select)
  - `cards/` — **ServiceCard**, **ProjectCard**, **TestimonialCard**, **ProcessStep**, **CTABand**
- **`ui_kits/website/`** — interactive marketing-site recreation (Home, Services, Projects w/ filters, Quote form) + `README.md`.
- **`ui_kits/mobile/`** — interactive phone-framed site/app (Home, Projects w/ filters, Quote) with slide-in menu + bottom tab bar + `README.md`.
- **`SKILL.md`** — Agent-Skill wrapper.

## Caveats
- Fonts are Google Fonts substitutions (no binaries in the repo).
- The logo is original (no client logo was provided).
- Icons: Lucide is a recommended substitution; service icons are emoji placeholders.
