---
name: aashray-buildcon-design
description: Use this skill to generate well-branded interfaces and assets for Aashray Buildcon (a Rajkot-based construction / general-contractor company), for production or throwaway prototypes/mocks. Contains brand guidelines, colours, type, fonts, logo assets, and UI-kit components for prototyping.
user-invocable: true
---

Read the `readme.md` file within this skill, and explore the other available files.

If creating visual artifacts (slides, mocks, throwaway prototypes, etc), copy assets out and create static HTML files for the user to view. If working on production code, copy assets and read the rules here to become an expert in designing with this brand.

Key facts:
- Brand: **safety amber `#F4A300`** on **graphite/charcoal** neutrals; **Spline Sans** (display) + **Inter** (body).
- Voice: confident, professional, plain-spoken ("we" to the client's "you"); Indian locale (₹, +91).
- Link `styles.css` for all tokens; logo suite is in `assets/`; components under `components/`; the marketing site recreation is in `ui_kits/website/`.

If the user invokes this skill without other guidance, ask what they want to build, ask a few questions, and act as an expert designer who outputs HTML artifacts _or_ production code, depending on the need.
