import React from "react";

/**
 * Aashray Buildcon — Button
 * Amber-forward CTA button used across the marketing site.
 */
export function Button({
  children,
  variant = "primary",
  size = "md",
  block = false,
  disabled = false,
  iconLeft = null,
  iconRight = null,
  as = "button",
  ...rest
}) {
  const sizes = {
    sm: { padding: "8px 14px", font: "var(--text-sm)", radius: "var(--radius-sm)", gap: "6px" },
    md: { padding: "12px 22px", font: "var(--text-base)", radius: "var(--radius-md)", gap: "8px" },
    lg: { padding: "16px 30px", font: "var(--text-lg)", radius: "var(--radius-md)", gap: "10px" },
  };
  const variants = {
    primary: {
      background: "var(--accent)",
      color: "var(--text-on-accent)",
      border: "1px solid var(--accent)",
      boxShadow: "var(--shadow-accent)",
    },
    secondary: {
      background: "transparent",
      color: "var(--text-strong)",
      border: "1px solid var(--border-strong)",
    },
    ghost: {
      background: "transparent",
      color: "var(--accent-press)",
      border: "1px solid transparent",
    },
    inverse: {
      background: "var(--surface-inverse)",
      color: "var(--text-inverse)",
      border: "1px solid var(--surface-inverse)",
    },
  };
  const s = sizes[size] || sizes.md;
  const v = variants[variant] || variants.primary;
  const Tag = as;

  return (
    <Tag
      disabled={as === "button" ? disabled : undefined}
      style={{
        display: block ? "flex" : "inline-flex",
        width: block ? "100%" : "auto",
        alignItems: "center",
        justifyContent: "center",
        gap: s.gap,
        padding: s.padding,
        fontFamily: "var(--font-display)",
        fontSize: s.font,
        fontWeight: "var(--weight-semibold)",
        lineHeight: 1,
        letterSpacing: "0.01em",
        borderRadius: s.radius,
        cursor: disabled ? "not-allowed" : "pointer",
        opacity: disabled ? 0.5 : 1,
        textDecoration: "none",
        whiteSpace: "nowrap",
        transition: "transform var(--dur-fast) var(--ease-standard), filter var(--dur-fast) var(--ease-standard)",
        ...v,
      }}
      onMouseDown={(e) => !disabled && (e.currentTarget.style.transform = "translateY(1px)")}
      onMouseUp={(e) => (e.currentTarget.style.transform = "translateY(0)")}
      onMouseLeave={(e) => (e.currentTarget.style.transform = "translateY(0)")}
      {...rest}
    >
      {iconLeft}
      {children}
      {iconRight}
    </Tag>
  );
}
