Section opener: eyebrow + title + optional lead. One per section.

```jsx
<SectionHeading
  eyebrow="What we do"
  title="Construction services, end to end"
  lead="From residential homes to commercial fit-outs, delivered on time and on budget."
  align="center"
/>
```

Set `invert` when placing on a charcoal/dark band.
