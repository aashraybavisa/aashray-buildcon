import React from "react";

/**
 * Aashray Buildcon — StatCard
 * Big-number trust stat (years, projects, sq-ft). Used in the trust bar.
 */
export function StatCard({ value, label, suffix = "", invert = false }) {
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: "var(--space-1)" }}>
      <div
        style={{
          display: "flex",
          alignItems: "baseline",
          gap: "2px",
          fontFamily: "var(--font-display)",
          fontSize: "var(--text-h1)",
          fontWeight: "var(--weight-bold)",
          lineHeight: 1,
          letterSpacing: "var(--tracking-tight)",
          color: invert ? "var(--text-inverse)" : "var(--text-strong)",
        }}
      >
        {value}
        {suffix && <span style={{ color: "var(--accent)" }}>{suffix}</span>}
      </div>
      <div
        style={{
          fontFamily: "var(--font-body)",
          fontSize: "var(--text-sm)",
          fontWeight: "var(--weight-medium)",
          color: invert ? "var(--graphite-300)" : "var(--text-muted)",
        }}
      >
        {label}
      </div>
    </div>
  );
}
