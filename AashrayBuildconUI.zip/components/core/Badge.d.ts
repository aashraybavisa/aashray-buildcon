import React from "react";

export interface BadgeProps {
  children?: React.ReactNode;
  /** Semantic color. @default "neutral" */
  tone?: "neutral" | "accent" | "success" | "warning" | "danger" | "info";
  /** Solid fill instead of soft tint. @default false */
  solid?: boolean;
  iconLeft?: React.ReactNode;
}

/**
 * Small pill for categories (Residential / Commercial), project status, or
 * trust flags (Licensed & Insured). Soft tint by default; `solid` for emphasis.
 */
export function Badge(props: BadgeProps): JSX.Element;
