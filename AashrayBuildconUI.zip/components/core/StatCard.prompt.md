Big-number trust stat. Group 3-4 in a row.

```jsx
<StatCard value="15" suffix="+" label="Years in business" />
<StatCard value="240" suffix="+" label="Projects delivered" />
<StatCard value="1.8M" suffix=" sq-ft" label="Built area" />
```

Set `invert` on charcoal bands.
