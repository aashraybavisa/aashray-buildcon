import React from "react";

export interface SectionHeadingProps {
  eyebrow?: React.ReactNode;
  title: React.ReactNode;
  lead?: React.ReactNode;
  /** @default "left" */
  align?: "left" | "center";
  /** Use on dark/charcoal bands. @default false */
  invert?: boolean;
}

/**
 * Eyebrow + title + lead trio that opens a marketing section. One per section;
 * keep the eyebrow to 2-4 words, the title to a single line where possible.
 */
export function SectionHeading(props: SectionHeadingProps): JSX.Element;
