Small pill for categories, status, or trust flags.

```jsx
<Badge tone="accent">Residential</Badge>
<Badge tone="success" solid>Completed</Badge>
<Badge tone="neutral">Rajkot</Badge>
```

Tones: `neutral` `accent` `success` `warning` `danger` `info`. Add `solid` for a filled pill.
