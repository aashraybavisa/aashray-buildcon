import React from "react";

export interface StatCardProps {
  /** The number, e.g. "150" or "1.2M" */
  value: React.ReactNode;
  label: React.ReactNode;
  /** Accent-colored suffix, e.g. "+" or "%" */
  suffix?: string;
  /** Use on dark bands. @default false */
  invert?: boolean;
}

/**
 * Big-number trust statistic (years in business, projects completed, sq-ft built).
 * Group 3-4 in the home-page trust bar.
 */
export function StatCard(props: StatCardProps): JSX.Element;
