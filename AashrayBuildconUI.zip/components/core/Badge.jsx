import React from "react";

/**
 * Aashray Buildcon — Badge
 * Small status / category pill. Use `tone` for semantic color.
 */
export function Badge({ children, tone = "neutral", solid = false, iconLeft = null }) {
  const map = {
    neutral: { soft: ["var(--surface-sunken)", "var(--text-body)"], solid: ["var(--graphite-700)", "#fff"] },
    accent:  { soft: ["var(--accent-soft)", "var(--accent-press)"], solid: ["var(--accent)", "var(--text-on-accent)"] },
    success: { soft: ["var(--success-50)", "var(--success-500)"], solid: ["var(--success-500)", "#fff"] },
    warning: { soft: ["var(--warning-50)", "var(--amber-700)"], solid: ["var(--warning-500)", "var(--graphite-900)"] },
    danger:  { soft: ["var(--danger-50)", "var(--danger-500)"], solid: ["var(--danger-500)", "#fff"] },
    info:    { soft: ["var(--info-50)", "var(--info-500)"], solid: ["var(--info-500)", "#fff"] },
  };
  const [bg, fg] = (map[tone] || map.neutral)[solid ? "solid" : "soft"];
  return (
    <span
      style={{
        display: "inline-flex",
        alignItems: "center",
        gap: "5px",
        padding: "4px 10px",
        background: bg,
        color: fg,
        fontFamily: "var(--font-body)",
        fontSize: "var(--text-xs)",
        fontWeight: "var(--weight-semibold)",
        letterSpacing: "0.02em",
        borderRadius: "var(--radius-pill)",
        lineHeight: 1.4,
        whiteSpace: "nowrap",
      }}
    >
      {iconLeft}
      {children}
    </span>
  );
}
