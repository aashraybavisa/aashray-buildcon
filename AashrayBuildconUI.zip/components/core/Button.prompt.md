Primary CTA button — use `variant="primary"` for the single most important action on a view, and `secondary`/`ghost` for supporting actions.

```jsx
<Button variant="primary" size="lg">Request a Quote</Button>
<Button variant="secondary">View Projects</Button>
<Button variant="ghost" size="sm">Learn more</Button>
```

Variants: `primary` (amber, on any surface), `secondary` (outlined), `ghost` (text), `inverse` (charcoal, for light/amber bands). Sizes: `sm` / `md` / `lg`. Props: `block`, `disabled`, `iconLeft`, `iconRight`, `as="a"` + `href`.
