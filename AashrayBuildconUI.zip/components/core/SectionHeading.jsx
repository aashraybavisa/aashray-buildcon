import React from "react";

/**
 * Aashray Buildcon — SectionHeading
 * Eyebrow + title + optional lead, used to open every marketing section.
 */
export function SectionHeading({
  eyebrow,
  title,
  lead,
  align = "left",
  invert = false,
}) {
  return (
    <div style={{ maxWidth: "720px", textAlign: align, marginInline: align === "center" ? "auto" : undefined }}>
      {eyebrow && (
        <div
          style={{
            color: invert ? "var(--accent)" : "var(--accent-press)",
            fontFamily: "var(--font-body)",
            fontSize: "var(--text-xs)",
            fontWeight: "var(--weight-semibold)",
            letterSpacing: "var(--tracking-eyebrow)",
            textTransform: "uppercase",
            marginBottom: "var(--space-3)",
          }}
        >
          {eyebrow}
        </div>
      )}
      <h2
        style={{
          margin: 0,
          color: invert ? "var(--text-inverse)" : "var(--text-strong)",
          fontFamily: "var(--font-display)",
          fontSize: "var(--text-h2)",
          fontWeight: "var(--weight-bold)",
          lineHeight: "var(--leading-snug)",
          letterSpacing: "var(--tracking-tight)",
          textWrap: "balance",
        }}
      >
        {title}
      </h2>
      {lead && (
        <p
          style={{
            margin: "var(--space-4) 0 0",
            color: invert ? "var(--graphite-300)" : "var(--text-muted)",
            fontFamily: "var(--font-body)",
            fontSize: "var(--text-lg)",
            lineHeight: "var(--leading-relaxed)",
            textWrap: "pretty",
          }}
        >
          {lead}
        </p>
      )}
    </div>
  );
}
