import React from "react";

export interface ButtonProps {
  children?: React.ReactNode;
  /** Visual style. @default "primary" */
  variant?: "primary" | "secondary" | "ghost" | "inverse";
  /** @default "md" */
  size?: "sm" | "md" | "lg";
  /** Full-width. @default false */
  block?: boolean;
  disabled?: boolean;
  iconLeft?: React.ReactNode;
  iconRight?: React.ReactNode;
  /** Render as a different element, e.g. "a". @default "button" */
  as?: "button" | "a";
  href?: string;
  onClick?: (e: React.MouseEvent) => void;
}

/**
 * Primary call-to-action button. Use `primary` for the single most important
 * action on a view (Request a Quote); `secondary` for supporting actions;
 * `ghost` for low-emphasis inline actions; `inverse` on light bands.
 * @startingPoint section="Core" subtitle="Amber CTA button" viewport="700x160"
 */
export function Button(props: ButtonProps): JSX.Element;
