import React from "react";

/** Charcoal placeholder shown when no image URL is provided. */
function Placeholder({ label, ratio = "16 / 10", radius = "0" }) {
  return (
    <div
      style={{
        aspectRatio: ratio,
        width: "100%",
        borderRadius: radius,
        background:
          "repeating-linear-gradient(135deg, var(--graphite-700) 0 14px, var(--graphite-800) 14px 28px)",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        color: "var(--graphite-400)",
        fontFamily: "var(--font-body)",
        fontSize: "var(--text-xs)",
        letterSpacing: "0.1em",
        textTransform: "uppercase",
      }}
    >
      {label || "Photo"}
    </div>
  );
}

/**
 * Aashray Buildcon — ServiceCard
 * Icon + title + excerpt card linking to a service detail page.
 */
export function ServiceCard({ icon, title, excerpt, meta, href = "#" }) {
  return (
    <a
      href={href}
      style={{
        display: "flex",
        flexDirection: "column",
        gap: "var(--space-3)",
        padding: "var(--space-5)",
        background: "var(--surface-card)",
        border: "1px solid var(--border)",
        borderRadius: "var(--radius-lg)",
        boxShadow: "var(--shadow-sm)",
        textDecoration: "none",
        transition: "transform var(--dur-base) var(--ease-out), box-shadow var(--dur-base), border-color var(--dur-base)",
      }}
      onMouseEnter={(e) => {
        e.currentTarget.style.transform = "translateY(-4px)";
        e.currentTarget.style.boxShadow = "var(--shadow-lg)";
        e.currentTarget.style.borderColor = "var(--accent-border)";
      }}
      onMouseLeave={(e) => {
        e.currentTarget.style.transform = "translateY(0)";
        e.currentTarget.style.boxShadow = "var(--shadow-sm)";
        e.currentTarget.style.borderColor = "var(--border)";
      }}
    >
      <div
        style={{
          width: 52,
          height: 52,
          borderRadius: "var(--radius-md)",
          background: "var(--accent-soft)",
          color: "var(--accent-press)",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          fontSize: 26,
        }}
      >
        {icon || "�£"}
      </div>
      <h3
        style={{
          margin: 0,
          fontFamily: "var(--font-display)",
          fontSize: "var(--text-h4)",
          fontWeight: "var(--weight-bold)",
          color: "var(--text-strong)",
        }}
      >
        {title}
      </h3>
      <p style={{ margin: 0, color: "var(--text-muted)", fontSize: "var(--text-base)", lineHeight: "var(--leading-normal)", flex: 1, textWrap: "pretty" }}>
        {excerpt}
      </p>
      <span style={{ color: "var(--accent-press)", fontWeight: "var(--weight-semibold)", fontSize: "var(--text-sm)", fontFamily: "var(--font-display)" }}>
        {meta || "Explore"} →
      </span>
    </a>
  );
}

ServiceCard.Placeholder = Placeholder;
