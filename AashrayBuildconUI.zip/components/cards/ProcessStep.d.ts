import React from "react";

export interface ProcessStepProps {
  /** Step number or short label. */
  step: React.ReactNode;
  title: React.ReactNode;
  children?: React.ReactNode;
  /** Hide the connector line on the final step. @default false */
  last?: boolean;
}

/**
 * One numbered step in the vertical "How we work" process stepper
 * (Consult → Design → Build → Handover). Render in order; mark the last `last`.
 */
export function ProcessStep(props: ProcessStepProps): JSX.Element;
