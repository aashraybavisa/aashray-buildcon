import React from "react";

export interface TestimonialCardProps {
  quote: React.ReactNode;
  name: React.ReactNode;
  role: React.ReactNode;
  /** 0-5 amber stars. @default 5 */
  rating?: number;
  /** Dark treatment for charcoal bands. @default false */
  invert?: boolean;
}

/**
 * Client testimonial with star rating and attribution. Use in the home-page
 * testimonials strip or the testimonials page grid.
 */
export function TestimonialCard(props: TestimonialCardProps): JSX.Element;
