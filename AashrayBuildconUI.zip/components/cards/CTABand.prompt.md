Full-width charcoal call-to-action band. Place near the footer to close a page.

```jsx
<CTABand
  title="Ready to build? Get a free quote."
  lead="Tell us about your project and we'll respond within one business day."
  actionLabel="Request a Quote" />
```
