Service teaser card — grid 3-up on the home page / services overview.

```jsx
<ServiceCard icon="🏠" title="Residential Construction"
  excerpt="Custom homes and apartments built to last, from foundation to finish." />
```

Props: `icon`, `title`, `excerpt`, `meta`, `href`. In production swap `icon` for a real vector icon node.
