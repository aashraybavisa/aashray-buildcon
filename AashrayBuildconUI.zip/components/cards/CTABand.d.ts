import React from "react";

export interface CTABandProps {
  title: React.ReactNode;
  lead?: React.ReactNode;
  /** @default "Request a Quote" */
  actionLabel?: React.ReactNode;
  href?: string;
  onAction?: (e: React.MouseEvent) => void;
}

/**
 * Full-width charcoal conversion band that closes a page ("Ready to start?").
 * One primary amber action. Place near the footer.
 */
export function CTABand(props: CTABandProps): JSX.Element;
