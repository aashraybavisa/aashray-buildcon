Numbered step for the process stepper. Render in order; set `last` on the final one.

```jsx
<ProcessStep step="1" title="Consult">We visit the site, understand your brief and budget.</ProcessStep>
<ProcessStep step="2" title="Design">Drawings, 3D views and a fixed quote.</ProcessStep>
<ProcessStep step="3" title="Handover" last>Snag-free handover with warranty.</ProcessStep>
```
