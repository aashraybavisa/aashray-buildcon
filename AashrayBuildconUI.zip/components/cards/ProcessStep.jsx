import React from "react";

/**
 * Aashray Buildcon — ProcessStep
 * Numbered step for the "How we work" stepper.
 */
export function ProcessStep({ step, title, children, last = false }) {
  return (
    <div style={{ display: "flex", gap: "var(--space-4)", position: "relative" }}>
      <div style={{ display: "flex", flexDirection: "column", alignItems: "center", flex: "none" }}>
        <div
          style={{
            width: 48,
            height: 48,
            borderRadius: "var(--radius-pill)",
            background: "var(--accent)",
            color: "var(--text-on-accent)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            fontFamily: "var(--font-display)",
            fontWeight: "var(--weight-bold)",
            fontSize: "var(--text-h4)",
            flex: "none",
          }}
        >
          {step}
        </div>
        {!last && <div style={{ flex: 1, width: 2, background: "var(--border)", marginTop: 6, minHeight: 24 }} />}
      </div>
      <div style={{ paddingBottom: last ? 0 : "var(--space-6)" }}>
        <h3 style={{ margin: "8px 0 6px", fontFamily: "var(--font-display)", fontSize: "var(--text-h4)", fontWeight: "var(--weight-bold)", color: "var(--text-strong)" }}>
          {title}
        </h3>
        <p style={{ margin: 0, color: "var(--text-muted)", fontSize: "var(--text-base)", lineHeight: "var(--leading-normal)", textWrap: "pretty" }}>
          {children}
        </p>
      </div>
    </div>
  );
}
