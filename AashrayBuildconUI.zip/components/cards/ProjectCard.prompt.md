Portfolio card — cover image + category + title + location/year. Cover zooms on hover.

```jsx
<ProjectCard image="/assets/villa.jpg" title="Kalavad Road Villa"
  category="Residential" location="Rajkot" year={2024} />
```

Falls back to a charcoal placeholder when `image` is omitted.
