Client testimonial — quote, star rating, attribution.

```jsx
<TestimonialCard rating={5}
  quote="They delivered our showroom two weeks early and spotless."
  name="Rakesh Mehta" role="Owner, Mehta Motors" />
```

Set `invert` on charcoal bands.
