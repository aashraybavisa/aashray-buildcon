import React from "react";

/**
 * Aashray Buildcon — CTABand
 * Full-width charcoal conversion band with headline + primary action.
 */
export function CTABand({ title, lead, actionLabel = "Request a Quote", href = "#", onAction }) {
  return (
    <section
      style={{
        background: "var(--surface-inverse)",
        borderRadius: "var(--radius-xl)",
        padding: "var(--space-8) var(--space-7)",
        display: "flex",
        flexWrap: "wrap",
        alignItems: "center",
        justifyContent: "space-between",
        gap: "var(--space-5)",
        position: "relative",
        overflow: "hidden",
      }}
    >
      <div style={{ position: "absolute", right: -40, top: -40, width: 220, height: 220, borderRadius: "var(--radius-pill)", background: "var(--accent)", opacity: 0.12 }} />
      <div style={{ maxWidth: 560, position: "relative" }}>
        <h2 style={{ margin: 0, fontFamily: "var(--font-display)", fontSize: "var(--text-h1)", fontWeight: "var(--weight-bold)", color: "var(--text-inverse)", lineHeight: "var(--leading-tight)", letterSpacing: "var(--tracking-tight)", textWrap: "balance" }}>
          {title}
        </h2>
        {lead && <p style={{ margin: "var(--space-3) 0 0", color: "var(--graphite-300)", fontSize: "var(--text-lg)", lineHeight: "var(--leading-relaxed)" }}>{lead}</p>}
      </div>
      <a
        href={href}
        onClick={onAction}
        style={{
          position: "relative",
          display: "inline-flex",
          alignItems: "center",
          gap: "var(--space-2)",
          padding: "16px 30px",
          background: "var(--accent)",
          color: "var(--text-on-accent)",
          fontFamily: "var(--font-display)",
          fontSize: "var(--text-lg)",
          fontWeight: "var(--weight-semibold)",
          borderRadius: "var(--radius-md)",
          textDecoration: "none",
          boxShadow: "var(--shadow-accent)",
          whiteSpace: "nowrap",
        }}
      >
        {actionLabel} →
      </a>
    </section>
  );
}
