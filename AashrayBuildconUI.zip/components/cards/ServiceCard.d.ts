import React from "react";

export interface ServiceCardProps {
  /** Emoji or glyph; swap for a real icon node in production. */
  icon?: React.ReactNode;
  title: React.ReactNode;
  excerpt: React.ReactNode;
  /** Link-affordance label. @default "Explore" */
  meta?: React.ReactNode;
  href?: string;
}

/**
 * Service teaser card (Residential, Commercial, Renovation…). Grid these 3-up
 * on the home page and services overview. Lifts on hover with an amber border.
 */
export function ServiceCard(props: ServiceCardProps): JSX.Element;
