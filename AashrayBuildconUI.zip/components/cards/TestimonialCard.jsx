import React from "react";

/**
 * Aashray Buildcon — TestimonialCard
 * Client quote with rating, name, role. For the testimonials carousel/grid.
 */
export function TestimonialCard({ quote, name, role, rating = 5, invert = false }) {
  return (
    <figure
      style={{
        margin: 0,
        display: "flex",
        flexDirection: "column",
        gap: "var(--space-4)",
        padding: "var(--space-6)",
        background: invert ? "var(--graphite-700)" : "var(--surface-card)",
        border: "1px solid " + (invert ? "var(--graphite-600)" : "var(--border)"),
        borderRadius: "var(--radius-lg)",
        boxShadow: invert ? "none" : "var(--shadow-sm)",
      }}
    >
      <div style={{ display: "flex", gap: 3, color: "var(--accent)", fontSize: 18, lineHeight: 1 }}>
        {Array.from({ length: 5 }).map((_, i) => (
          <span key={i} style={{ opacity: i < rating ? 1 : 0.25 }}>★</span>
        ))}
      </div>
      <blockquote
        style={{
          margin: 0,
          fontFamily: "var(--font-display)",
          fontSize: "var(--text-h4)",
          fontWeight: "var(--weight-medium)",
          lineHeight: "var(--leading-snug)",
          color: invert ? "var(--text-inverse)" : "var(--text-strong)",
          textWrap: "pretty",
        }}
      >
        “{quote}”
      </blockquote>
      <figcaption style={{ display: "flex", flexDirection: "column", gap: 2, marginTop: "auto" }}>
        <span style={{ fontWeight: "var(--weight-semibold)", color: invert ? "var(--text-inverse)" : "var(--text-strong)", fontSize: "var(--text-base)" }}>{name}</span>
        <span style={{ color: invert ? "var(--graphite-300)" : "var(--text-muted)", fontSize: "var(--text-sm)" }}>{role}</span>
      </figcaption>
    </figure>
  );
}
