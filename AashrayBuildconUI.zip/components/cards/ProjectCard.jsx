import React from "react";

/**
 * Aashray Buildcon — ProjectCard
 * Cover image + category badge + title + location/year, for portfolio grids.
 */
export function ProjectCard({ image, title, category = "Residential", location, year, href = "#" }) {
  const toneMap = { Residential: "accent", Commercial: "info", Renovation: "success" };
  return (
    <a
      href={href}
      style={{
        display: "block",
        borderRadius: "var(--radius-lg)",
        overflow: "hidden",
        background: "var(--surface-card)",
        border: "1px solid var(--border)",
        textDecoration: "none",
        boxShadow: "var(--shadow-sm)",
        transition: "transform var(--dur-base) var(--ease-out), box-shadow var(--dur-base)",
      }}
      onMouseEnter={(e) => {
        e.currentTarget.style.transform = "translateY(-4px)";
        e.currentTarget.style.boxShadow = "var(--shadow-lg)";
        e.currentTarget.querySelector("[data-cover]").style.transform = "scale(1.05)";
      }}
      onMouseLeave={(e) => {
        e.currentTarget.style.transform = "translateY(0)";
        e.currentTarget.style.boxShadow = "var(--shadow-sm)";
        e.currentTarget.querySelector("[data-cover]").style.transform = "scale(1)";
      }}
    >
      <div style={{ position: "relative", overflow: "hidden", aspectRatio: "4 / 3" }}>
        <div
          data-cover
          style={{
            position: "absolute",
            inset: 0,
            background: image
              ? `center/cover no-repeat url(${image})`
              : "repeating-linear-gradient(135deg, var(--graphite-700) 0 14px, var(--graphite-800) 14px 28px)",
            transition: "transform var(--dur-slow) var(--ease-out)",
          }}
        />
        <span
          style={{
            position: "absolute",
            top: 12,
            left: 12,
            padding: "4px 10px",
            borderRadius: "var(--radius-pill)",
            fontSize: "var(--text-xs)",
            fontWeight: "var(--weight-semibold)",
            background: "var(--surface-card)",
            color: "var(--text-strong)",
            boxShadow: "var(--shadow-sm)",
          }}
        >
          {category}
        </span>
      </div>
      <div style={{ padding: "var(--space-4) var(--space-5) var(--space-5)" }}>
        <h3 style={{ margin: 0, fontFamily: "var(--font-display)", fontSize: "var(--text-h4)", fontWeight: "var(--weight-bold)", color: "var(--text-strong)" }}>
          {title}
        </h3>
        <div style={{ marginTop: "var(--space-2)", color: "var(--text-muted)", fontSize: "var(--text-sm)", display: "flex", gap: "var(--space-2)" }}>
          {location && <span>{location}</span>}
          {location && year && <span aria-hidden>·</span>}
          {year && <span>{year}</span>}
        </div>
      </div>
    </a>
  );
}
