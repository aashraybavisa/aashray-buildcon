import React from "react";

export interface ProjectCardProps {
  /** Cover image URL. Falls back to a charcoal placeholder. */
  image?: string;
  title: React.ReactNode;
  /** @default "Residential" */
  category?: "Residential" | "Commercial" | "Renovation" | string;
  location?: React.ReactNode;
  year?: React.ReactNode;
  href?: string;
}

/**
 * Portfolio project card with cover image, category tag, and location/year.
 * Cover zooms subtly on hover. Use in the filterable projects grid.
 */
export function ProjectCard(props: ProjectCardProps): JSX.Element;
