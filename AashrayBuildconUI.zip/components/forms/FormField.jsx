import React from "react";

/**
 * Aashray Buildcon — FormField
 * Label + control (input / textarea / select) + hint / error.
 * The workhorse of the Contact and Quote conversion forms.
 */
export function FormField({
  label,
  name,
  type = "text",
  as = "input",
  placeholder,
  hint,
  error,
  required = false,
  options = [],
  rows = 4,
  value,
  onChange,
  ...rest
}) {
  const id = name || label;
  const controlStyle = {
    width: "100%",
    boxSizing: "border-box",
    padding: as === "textarea" ? "12px 14px" : "0 14px",
    height: as === "textarea" ? "auto" : "48px",
    minHeight: as === "textarea" ? rows * 22 + "px" : undefined,
    fontFamily: "var(--font-body)",
    fontSize: "var(--text-base)",
    color: "var(--text-strong)",
    background: "var(--surface-card)",
    border: "1px solid " + (error ? "var(--danger-500)" : "var(--border-strong)"),
    borderRadius: "var(--radius-md)",
    outline: "none",
    transition: "border-color var(--dur-fast), box-shadow var(--dur-fast)",
    appearance: as === "select" ? "none" : undefined,
  };
  const focus = (e) => {
    e.currentTarget.style.borderColor = "var(--accent)";
    e.currentTarget.style.boxShadow = "0 0 0 3px var(--accent-soft)";
  };
  const blur = (e) => {
    e.currentTarget.style.borderColor = error ? "var(--danger-500)" : "var(--border-strong)";
    e.currentTarget.style.boxShadow = "none";
  };

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: "var(--space-2)" }}>
      {label && (
        <label
          htmlFor={id}
          style={{
            fontFamily: "var(--font-body)",
            fontSize: "var(--text-sm)",
            fontWeight: "var(--weight-semibold)",
            color: "var(--text-strong)",
          }}
        >
          {label}
          {required && <span style={{ color: "var(--danger-500)", marginLeft: 3 }}>*</span>}
        </label>
      )}

      {as === "textarea" ? (
        <textarea id={id} name={name} placeholder={placeholder} rows={rows} value={value} onChange={onChange} onFocus={focus} onBlur={blur} style={{ ...controlStyle, resize: "vertical" }} {...rest} />
      ) : as === "select" ? (
        <div style={{ position: "relative" }}>
          <select id={id} name={name} value={value} onChange={onChange} onFocus={focus} onBlur={blur} style={controlStyle} {...rest}>
            {placeholder && <option value="">{placeholder}</option>}
            {options.map((o) => {
              const val = typeof o === "string" ? o : o.value;
              const lbl = typeof o === "string" ? o : o.label;
              return <option key={val} value={val}>{lbl}</option>;
            })}
          </select>
          <span style={{ position: "absolute", right: 14, top: "50%", transform: "translateY(-50%)", pointerEvents: "none", color: "var(--text-muted)" }}>▾</span>
        </div>
      ) : (
        <input id={id} name={name} type={type} placeholder={placeholder} value={value} onChange={onChange} onFocus={focus} onBlur={blur} style={controlStyle} {...rest} />
      )}

      {error ? (
        <span style={{ fontSize: "var(--text-sm)", color: "var(--danger-500)" }}>{error}</span>
      ) : hint ? (
        <span style={{ fontSize: "var(--text-sm)", color: "var(--text-muted)" }}>{hint}</span>
      ) : null}
    </div>
  );
}
