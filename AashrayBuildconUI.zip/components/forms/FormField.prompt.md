Labelled input / textarea / select with hint + error states. The building block of the Contact and Quote forms.

```jsx
<FormField label="Full name" name="name" placeholder="Your name" required />
<FormField label="Project type" as="select" placeholder="Select…"
  options={["Residential", "Commercial", "Renovation"]} />
<FormField label="Details" as="textarea" rows={5} hint="Tell us about scope and timeline." />
<FormField label="Email" type="email" error="Enter a valid email." />
```
