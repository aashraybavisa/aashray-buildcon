import React from "react";

export interface FormFieldOption { label: string; value: string; }

export interface FormFieldProps {
  label?: React.ReactNode;
  name?: string;
  /** Control kind. @default "input" */
  as?: "input" | "textarea" | "select";
  /** Native input type when as="input". @default "text" */
  type?: string;
  placeholder?: string;
  hint?: React.ReactNode;
  /** Error message; also switches the control to the danger border. */
  error?: React.ReactNode;
  required?: boolean;
  /** For as="select"; strings or {label,value}. */
  options?: (string | FormFieldOption)[];
  rows?: number;
  value?: string;
  onChange?: (e: React.ChangeEvent) => void;
}

/**
 * Labelled form control (input / textarea / select) with hint and error states.
 * Compose these to build the Contact and Quote forms; amber focus ring throughout.
 */
export function FormField(props: FormFieldProps): JSX.Element;
