# Aashray Buildcon — Mobile UI Kit

Interactive phone-framed recreation of the Aashray Buildcon site / app (the Expo codebase ships native from the same source, so this doubles as the app view). Self-contained `index.html`, styled with the design-system tokens and logo assets.

## What's inside (interactive)
- **Home** — charcoal hero + stacked CTAs, 2×2 trust stats, service rows, featured projects, CTA card.
- **Projects** — horizontally-scrolling category filter chips + single-column project cards.
- **Quote** — the conversion form (name, phone, project type, budget, details) with a success state.
- **Chrome** — status bar, sticky header with a full-screen slide-in **menu**, and a bottom **tab bar** (Home / Work / Quote).

## Notes
- Design width 390px in a phone bezel; screens scroll inside the frame.
- Photos are charcoal-hatch placeholders; service icons are emoji placeholders (swap for Lucide — see root `readme.md`).
- Built with `React.createElement` + inline styles, transformed in-browser with the classic React runtime.
