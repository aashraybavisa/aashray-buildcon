# Aashray Buildcon — Website UI Kit

Interactive, high-fidelity recreation of the Aashray Buildcon marketing site. Cosmetic recreation using the design-system tokens (`styles.css`) and logo assets — a single self-contained `index.html`.

## Screens (click the nav to move between them)
- **Home** — charcoal hero + amber CTAs, trust-stat bar, services grid, featured projects, 4-step process, testimonial, CTA band, footer.
- **Services** — dark section intro + 6-service grid.
- **Projects** — portfolio grid with working category filter (All / Residential / Commercial / Renovation).
- **Quote** — the primary conversion form (name, phone, project type, budget, timeline, details) with a success state.

## Notes
- Photography uses a charcoal diagonal-hatch placeholder; drop in real project photos.
- Service icons are emoji placeholders — replace with Lucide (see root `readme.md` → Iconography).
- Screens are factored into function components inside `index.html` (`Header`, `Footer`, `Home`, `Services`, `Projects`, `Quote`, `WebsiteApp`) and mirrored in `screens.jsx` as readable source. `index.html` is the runnable artifact (JSX is transformed in-browser with the classic React runtime).
