/* Aashray Buildcon — Website UI kit screens
   Self-contained cosmetic recreation (inline styles + design-system CSS tokens).
   Screens: Home, Services, Projects, Quote — with a sticky header + footer. */

const ASSET = "../../assets/";

/* ---------- shared bits ---------- */
function Photo({ label = "Photo", ratio = "16 / 10", radius = 0, style }) {
  return (
    <div style={{
      aspectRatio: ratio, width: "100%", borderRadius: radius,
      background: "repeating-linear-gradient(135deg, var(--graphite-700) 0 16px, var(--graphite-800) 16px 32px)",
      display: "flex", alignItems: "center", justifyContent: "center",
      color: "var(--graphite-400)", fontSize: 12, letterSpacing: ".14em", textTransform: "uppercase",
      ...style,
    }}>{label}</div>
  );
}

function Btn({ children, variant = "primary", size = "md", onClick, style }) {
  const S = { sm: "8px 14px", md: "12px 22px", lg: "16px 30px" }[size];
  const F = { sm: 14, md: 16, lg: 18 }[size];
  const V = {
    primary: { background: "var(--accent)", color: "var(--text-on-accent)", border: "1px solid var(--accent)", boxShadow: "var(--shadow-accent)" },
    secondary: { background: "transparent", color: "var(--text-strong)", border: "1px solid var(--border-strong)" },
    inverse: { background: "#fff", color: "var(--graphite-900)", border: "1px solid #fff" },
    ghostLight: { background: "transparent", color: "#fff", border: "1px solid var(--graphite-600)" },
  }[variant];
  return (
    <button onClick={onClick} style={{
      display: "inline-flex", alignItems: "center", justifyContent: "center", gap: 8,
      padding: S, fontFamily: "var(--font-display)", fontSize: F, fontWeight: 600, lineHeight: 1,
      borderRadius: "var(--radius-md)", cursor: "pointer", whiteSpace: "nowrap",
      transition: "transform .12s", ...V, ...style,
    }}
      onMouseDown={e => e.currentTarget.style.transform = "translateY(1px)"}
      onMouseUp={e => e.currentTarget.style.transform = "translateY(0)"}
      onMouseLeave={e => e.currentTarget.style.transform = "translateY(0)"}
    >{children}</button>
  );
}

function Eyebrow({ children, invert }) {
  return <div style={{ color: invert ? "var(--accent)" : "var(--accent-press)", fontSize: 12, fontWeight: 600, letterSpacing: ".12em", textTransform: "uppercase", marginBottom: 14 }}>{children}</div>;
}
function H2({ children, invert, style }) {
  return <h2 style={{ margin: 0, fontFamily: "var(--font-display)", fontSize: 34, fontWeight: 700, lineHeight: 1.15, letterSpacing: "-.02em", color: invert ? "#fff" : "var(--text-strong)", textWrap: "balance", ...style }}>{children}</h2>;
}
function Badge({ children, tone = "neutral" }) {
  const c = { neutral: ["var(--surface-sunken)", "var(--text-body)"], accent: ["var(--accent-soft)", "var(--accent-press)"], info: ["var(--info-50)", "var(--info-500)"], success: ["var(--success-50)", "var(--success-500)"] }[tone];
  return <span style={{ background: c[0], color: c[1], fontSize: 12, fontWeight: 600, padding: "4px 10px", borderRadius: 999 }}>{children}</span>;
}
const Container = ({ children, style }) => <div style={{ maxWidth: 1200, margin: "0 auto", padding: "0 32px", ...style }}>{children}</div>;

/* ---------- header ---------- */
function Header({ route, go }) {
  const links = [["home", "Home"], ["services", "Services"], ["projects", "Projects"], ["about", "About"], ["contact", "Contact"]];
  return (
    <header style={{ position: "sticky", top: 0, zIndex: 50, background: "color-mix(in srgb, var(--surface-page) 88%, transparent)", backdropFilter: "blur(10px)", borderBottom: "1px solid var(--border)" }}>
      <Container style={{ display: "flex", alignItems: "center", justifyContent: "space-between", height: 74 }}>
        <a onClick={() => go("home")} style={{ display: "flex", alignItems: "center", gap: 12, cursor: "pointer", textDecoration: "none" }}>
          <img src={ASSET + "logo-tile.svg"} width="42" height="42" alt="" />
          <span style={{ display: "flex", flexDirection: "column", lineHeight: 1 }}>
            <b style={{ fontFamily: "var(--font-display)", fontSize: 19, color: "var(--text-strong)", letterSpacing: "-.01em" }}>Aashray Buildcon</b>
            <span style={{ fontSize: 9.5, letterSpacing: ".26em", textTransform: "uppercase", color: "var(--accent-press)", marginTop: 4, fontWeight: 600 }}>Rajkot</span>
          </span>
        </a>
        <nav style={{ display: "flex", alignItems: "center", gap: 28 }}>
          {links.map(([k, l]) => (
            <a key={k} onClick={() => go(k)} style={{ cursor: "pointer", fontSize: 15, fontWeight: 500, color: route === k ? "var(--text-strong)" : "var(--text-muted)", textDecoration: "none", position: "relative" }}>
              {l}
              {route === k && <span style={{ position: "absolute", left: 0, right: 0, bottom: -26, height: 3, background: "var(--accent)", borderRadius: 3 }} />}
            </a>
          ))}
          <Btn size="sm" onClick={() => go("quote")}>Request a Quote</Btn>
        </nav>
      </Container>
    </header>
  );
}

/* ---------- footer ---------- */
function Footer({ go }) {
  const col = (title, items) => (
    <div>
      <div style={{ fontSize: 12, fontWeight: 600, letterSpacing: ".1em", textTransform: "uppercase", color: "var(--graphite-400)", marginBottom: 16 }}>{title}</div>
      <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
        {items.map(i => <a key={i} onClick={() => go("services")} style={{ color: "var(--graphite-300)", fontSize: 14, cursor: "pointer", textDecoration: "none" }}>{i}</a>)}
      </div>
    </div>
  );
  return (
    <footer style={{ background: "var(--graphite-900)", paddingTop: 64, paddingBottom: 32, marginTop: 0 }}>
      <Container>
        <div style={{ display: "grid", gridTemplateColumns: "1.6fr 1fr 1fr 1fr", gap: 40, paddingBottom: 48, borderBottom: "1px solid var(--graphite-700)" }}>
          <div>
            <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 16 }}>
              <img src={ASSET + "logo-tile.svg"} width="40" height="40" alt="" />
              <b style={{ fontFamily: "var(--font-display)", fontSize: 18, color: "#fff" }}>Aashray Buildcon</b>
            </div>
            <p style={{ color: "var(--graphite-400)", fontSize: 14, lineHeight: 1.7, maxWidth: 300, margin: 0 }}>
              A trusted general contractor building residential and commercial spaces across Rajkot and Saurashtra since 2009.
            </p>
          </div>
          {col("Services", ["Residential", "Commercial", "Renovation", "Interior fit-out"])}
          {col("Company", ["About us", "Projects", "Process", "Careers"])}
          <div>
            <div style={{ fontSize: 12, fontWeight: 600, letterSpacing: ".1em", textTransform: "uppercase", color: "var(--graphite-400)", marginBottom: 16 }}>Get in touch</div>
            <div style={{ display: "flex", flexDirection: "column", gap: 10, color: "var(--graphite-300)", fontSize: 14 }}>
              <span>150 Ft Ring Road, Rajkot</span>
              <span style={{ fontFamily: "var(--font-mono)" }}>+91 98240 00000</span>
              <span>hello@aashraybuildcon.in</span>
            </div>
          </div>
        </div>
        <div style={{ display: "flex", justifyContent: "space-between", paddingTop: 24, color: "var(--graphite-500)", fontSize: 13 }}>
          <span>© 2026 Aashray Buildcon. All rights reserved.</span>
          <span>Licensed &amp; Insured · GST 24XXXXX</span>
        </div>
      </Container>
    </footer>
  );
}

/* ---------- service card ---------- */
function ServiceCard({ icon, title, excerpt }) {
  const [h, setH] = React.useState(false);
  return (
    <div onMouseEnter={() => setH(true)} onMouseLeave={() => setH(false)}
      style={{ display: "flex", flexDirection: "column", gap: 14, padding: 26, background: "var(--surface-card)", border: "1px solid " + (h ? "var(--accent-border)" : "var(--border)"), borderRadius: 16, boxShadow: h ? "var(--shadow-lg)" : "var(--shadow-sm)", transform: h ? "translateY(-4px)" : "none", transition: "all .2s", cursor: "pointer" }}>
      <div style={{ width: 52, height: 52, borderRadius: 10, background: "var(--accent-soft)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 26 }}>{icon}</div>
      <h3 style={{ margin: 0, fontFamily: "var(--font-display)", fontSize: 20, fontWeight: 700, color: "var(--text-strong)" }}>{title}</h3>
      <p style={{ margin: 0, color: "var(--text-muted)", fontSize: 15, lineHeight: 1.6, flex: 1 }}>{excerpt}</p>
      <span style={{ color: "var(--accent-press)", fontWeight: 600, fontSize: 14, fontFamily: "var(--font-display)" }}>Explore →</span>
    </div>
  );
}

/* ---------- project card ---------- */
function ProjectCard({ title, category, location, year }) {
  const [h, setH] = React.useState(false);
  return (
    <div onMouseEnter={() => setH(true)} onMouseLeave={() => setH(false)}
      style={{ borderRadius: 16, overflow: "hidden", background: "var(--surface-card)", border: "1px solid var(--border)", boxShadow: h ? "var(--shadow-lg)" : "var(--shadow-sm)", transform: h ? "translateY(-4px)" : "none", transition: "all .2s", cursor: "pointer" }}>
      <div style={{ position: "relative", overflow: "hidden" }}>
        <Photo ratio="4 / 3" label={category} style={{ transform: h ? "scale(1.05)" : "none", transition: "transform .4s" }} />
        <span style={{ position: "absolute", top: 12, left: 12, padding: "4px 10px", borderRadius: 999, fontSize: 12, fontWeight: 600, background: "#fff", color: "var(--text-strong)", boxShadow: "var(--shadow-sm)" }}>{category}</span>
      </div>
      <div style={{ padding: "16px 20px 20px" }}>
        <h3 style={{ margin: 0, fontFamily: "var(--font-display)", fontSize: 19, fontWeight: 700, color: "var(--text-strong)" }}>{title}</h3>
        <div style={{ marginTop: 8, color: "var(--text-muted)", fontSize: 14, display: "flex", gap: 8 }}><span>{location}</span><span>·</span><span>{year}</span></div>
      </div>
    </div>
  );
}

/* ==================== HOME ==================== */
function Home({ go }) {
  const stats = [["15", "+", "Years building"], ["240", "+", "Projects delivered"], ["1.8M", " sq-ft", "Built area"], ["98", "%", "On-time handover"]];
  const services = [
    ["🏠", "Residential", "Custom homes and apartments built to last, from foundation to finish."],
    ["🏢", "Commercial", "Showrooms, offices and retail spaces delivered to spec and on schedule."],
    ["🛠️", "Renovation", "Remodels and structural upgrades that modernise any space."],
  ];
  const projects = [["Kalavad Road Villa", "Residential", "Rajkot", 2024], ["Crystal Mall Fit-out", "Commercial", "Rajkot", 2023], ["Heritage Bungalow", "Renovation", "Jamnagar", 2023]];
  return (
    <div>
      {/* hero */}
      <section style={{ background: "var(--surface-inverse)", position: "relative", overflow: "hidden" }}>
        <Container style={{ display: "grid", gridTemplateColumns: "1.05fr .95fr", gap: 48, alignItems: "center", padding: "84px 32px 88px" }}>
          <div>
            <Eyebrow invert>Rajkot · Since 2009</Eyebrow>
            <h1 style={{ margin: 0, fontFamily: "var(--font-display)", fontSize: 56, fontWeight: 700, lineHeight: 1.05, letterSpacing: "-.03em", color: "#fff", textWrap: "balance" }}>
              Building Rajkot's future, one project at a time.
            </h1>
            <p style={{ color: "var(--graphite-300)", fontSize: 19, lineHeight: 1.6, maxWidth: 480, margin: "22px 0 30px" }}>
              A trusted general contractor delivering residential and commercial builds — on time, on budget, and safety-first.
            </p>
            <div style={{ display: "flex", gap: 14 }}>
              <Btn size="lg" onClick={() => go("quote")}>Request a Quote →</Btn>
              <Btn size="lg" variant="ghostLight" onClick={() => go("projects")}>View Projects</Btn>
            </div>
          </div>
          <div style={{ borderRadius: 20, overflow: "hidden", boxShadow: "var(--shadow-lg)" }}>
            <Photo ratio="4 / 5" label="Hero build photo" />
          </div>
        </Container>
      </section>

      {/* trust bar */}
      <section style={{ background: "var(--graphite-900)", borderTop: "1px solid var(--graphite-700)" }}>
        <Container style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 24, padding: "36px 32px" }}>
          {stats.map(([v, s, l]) => (
            <div key={l}>
              <div style={{ fontFamily: "var(--font-display)", fontSize: 40, fontWeight: 700, color: "#fff", lineHeight: 1, letterSpacing: "-.02em" }}>{v}<span style={{ color: "var(--accent)" }}>{s}</span></div>
              <div style={{ color: "var(--graphite-400)", fontSize: 14, marginTop: 6 }}>{l}</div>
            </div>
          ))}
        </Container>
      </section>

      {/* services */}
      <section style={{ padding: "88px 0" }}>
        <Container>
          <div style={{ textAlign: "center", maxWidth: 640, margin: "0 auto 48px" }}>
            <Eyebrow>What we do</Eyebrow>
            <H2>Construction services, end to end</H2>
            <p style={{ color: "var(--text-muted)", fontSize: 18, lineHeight: 1.6, marginTop: 16 }}>From the first drawing to the final handover, we manage every phase in-house.</p>
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 20 }}>
            {services.map(([i, t, e]) => <ServiceCard key={t} icon={i} title={t} excerpt={e} />)}
          </div>
        </Container>
      </section>

      {/* featured projects */}
      <section style={{ padding: "0 0 88px" }}>
        <Container>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end", marginBottom: 32 }}>
            <div><Eyebrow>Recent work</Eyebrow><H2>Featured projects</H2></div>
            <Btn variant="secondary" onClick={() => go("projects")}>All projects</Btn>
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 20 }}>
            {projects.map(p => <ProjectCard key={p[0]} title={p[0]} category={p[1]} location={p[2]} year={p[3]} />)}
          </div>
        </Container>
      </section>

      {/* process */}
      <section style={{ background: "var(--surface-raised)", padding: "88px 0" }}>
        <Container>
          <div style={{ maxWidth: 620, marginBottom: 40 }}><Eyebrow>How we work</Eyebrow><H2>A clear path from idea to handover</H2></div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 20 }}>
            {[["1", "Consult", "We visit the site, understand your brief and budget."], ["2", "Design", "Drawings, 3D views and a fixed, itemised quote."], ["3", "Build", "Certified teams, weekly updates, strict safety."], ["4", "Handover", "Snag-free handover with warranty and support."]].map(([n, t, d]) => (
              <div key={n} style={{ background: "var(--surface-card)", border: "1px solid var(--border)", borderRadius: 16, padding: 24 }}>
                <div style={{ width: 44, height: 44, borderRadius: 999, background: "var(--accent)", color: "var(--graphite-900)", display: "flex", alignItems: "center", justifyContent: "center", fontFamily: "var(--font-display)", fontWeight: 700, fontSize: 20, marginBottom: 16 }}>{n}</div>
                <h3 style={{ margin: "0 0 6px", fontFamily: "var(--font-display)", fontSize: 19, fontWeight: 700, color: "var(--text-strong)" }}>{t}</h3>
                <p style={{ margin: 0, color: "var(--text-muted)", fontSize: 14.5, lineHeight: 1.6 }}>{d}</p>
              </div>
            ))}
          </div>
        </Container>
      </section>

      {/* testimonial */}
      <section style={{ padding: "88px 0" }}>
        <Container style={{ maxWidth: 860, textAlign: "center" }}>
          <div style={{ color: "var(--accent)", fontSize: 22, marginBottom: 18 }}>★★★★★</div>
          <blockquote style={{ margin: 0, fontFamily: "var(--font-display)", fontSize: 30, fontWeight: 500, lineHeight: 1.35, color: "var(--text-strong)", letterSpacing: "-.01em", textWrap: "balance" }}>
            “They delivered our showroom two weeks early and spotless. Transparent quotes, weekly updates, zero surprises.”
          </blockquote>
          <div style={{ marginTop: 24, fontWeight: 600, color: "var(--text-strong)" }}>Rakesh Mehta</div>
          <div style={{ color: "var(--text-muted)", fontSize: 14 }}>Owner, Mehta Motors</div>
        </Container>
      </section>

      {/* CTA */}
      <section style={{ padding: "0 0 88px" }}>
        <Container>
          <div style={{ background: "var(--surface-inverse)", borderRadius: 24, padding: "64px 48px", display: "flex", flexWrap: "wrap", alignItems: "center", justifyContent: "space-between", gap: 24, position: "relative", overflow: "hidden" }}>
            <div style={{ position: "absolute", right: -40, top: -40, width: 220, height: 220, borderRadius: 999, background: "var(--accent)", opacity: .12 }} />
            <div style={{ position: "relative", maxWidth: 560 }}>
              <H2 invert style={{ fontSize: 40 }}>Ready to build? Get a free quote.</H2>
              <p style={{ color: "var(--graphite-300)", fontSize: 18, marginTop: 12 }}>Tell us about your project and we'll respond within one business day.</p>
            </div>
            <Btn size="lg" onClick={() => go("quote")} style={{ position: "relative" }}>Request a Quote →</Btn>
          </div>
        </Container>
      </section>
    </div>
  );
}

/* ==================== SERVICES ==================== */
function Services({ go }) {
  const items = [
    ["🏠", "Residential Construction", "Custom homes, villas and apartments built to last."],
    ["🏢", "Commercial Construction", "Showrooms, offices, retail and industrial sheds."],
    ["🛠️", "Renovation & Remodeling", "Structural upgrades and full property makeovers."],
    ["🪟", "Interior Fit-out", "Turnkey interiors for homes and workspaces."],
    ["📐", "Project Management", "End-to-end management and cost consulting."],
    ["🧱", "Maintenance", "Ongoing upkeep and annual maintenance contracts."],
  ];
  return (
    <div>
      <section style={{ background: "var(--surface-inverse)", padding: "72px 0" }}>
        <Container><Eyebrow invert>Services</Eyebrow><H2 invert style={{ fontSize: 46, maxWidth: 720 }}>Everything you need, under one contract.</H2></Container>
      </section>
      <section style={{ padding: "72px 0" }}>
        <Container>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 20 }}>
            {items.map(([i, t, e]) => <ServiceCard key={t} icon={i} title={t} excerpt={e} />)}
          </div>
        </Container>
      </section>
    </div>
  );
}

/* ==================== PROJECTS ==================== */
function Projects() {
  const all = [
    ["Kalavad Road Villa", "Residential", "Rajkot", 2024], ["Crystal Mall Fit-out", "Commercial", "Rajkot", 2023],
    ["Heritage Bungalow", "Renovation", "Jamnagar", 2023], ["Skyline Residency", "Residential", "Rajkot", 2024],
    ["Aditya Corporate Park", "Commercial", "Morbi", 2022], ["Riverside Farmhouse", "Renovation", "Gondal", 2022],
  ];
  const [filter, setFilter] = React.useState("All");
  const tabs = ["All", "Residential", "Commercial", "Renovation"];
  const shown = filter === "All" ? all : all.filter(p => p[1] === filter);
  return (
    <div>
      <section style={{ background: "var(--surface-inverse)", padding: "72px 0" }}>
        <Container><Eyebrow invert>Portfolio</Eyebrow><H2 invert style={{ fontSize: 46 }}>Projects we're proud of.</H2></Container>
      </section>
      <section style={{ padding: "48px 0 72px" }}>
        <Container>
          <div style={{ display: "flex", gap: 10, marginBottom: 32 }}>
            {tabs.map(t => (
              <button key={t} onClick={() => setFilter(t)} style={{ padding: "9px 18px", borderRadius: 999, border: "1px solid " + (filter === t ? "var(--accent)" : "var(--border-strong)"), background: filter === t ? "var(--accent)" : "transparent", color: filter === t ? "var(--graphite-900)" : "var(--text-body)", fontWeight: 600, fontSize: 14, cursor: "pointer", fontFamily: "var(--font-display)" }}>{t}</button>
            ))}
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 20 }}>
            {shown.map(p => <ProjectCard key={p[0]} title={p[0]} category={p[1]} location={p[2]} year={p[3]} />)}
          </div>
        </Container>
      </section>
    </div>
  );
}

/* ==================== QUOTE ==================== */
function Field({ label, children, required }) {
  return (
    <label style={{ display: "flex", flexDirection: "column", gap: 8 }}>
      <span style={{ fontSize: 14, fontWeight: 600, color: "var(--text-strong)" }}>{label}{required && <span style={{ color: "var(--danger-500)", marginLeft: 3 }}>*</span>}</span>
      {children}
    </label>
  );
}
function Quote() {
  const [sent, setSent] = React.useState(false);
  const inputStyle = { height: 48, padding: "0 14px", fontFamily: "var(--font-body)", fontSize: 16, color: "var(--text-strong)", background: "var(--surface-card)", border: "1px solid var(--border-strong)", borderRadius: 10, outline: "none", width: "100%", boxSizing: "border-box" };
  const focus = e => { e.target.style.borderColor = "var(--accent)"; e.target.style.boxShadow = "0 0 0 3px var(--accent-soft)"; };
  const blur = e => { e.target.style.borderColor = "var(--border-strong)"; e.target.style.boxShadow = "none"; };
  return (
    <section style={{ background: "var(--surface-raised)", padding: "72px 0", minHeight: "70vh" }}>
      <Container style={{ maxWidth: 900 }}>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1.1fr", gap: 48, alignItems: "start" }}>
          <div>
            <Eyebrow>Request a Quote</Eyebrow>
            <H2>Tell us about your project.</H2>
            <p style={{ color: "var(--text-muted)", fontSize: 17, lineHeight: 1.7, marginTop: 16 }}>Share a few details and our team will reply within one business day with next steps and a rough estimate.</p>
            <div style={{ marginTop: 28, display: "flex", flexDirection: "column", gap: 14 }}>
              {["Free, no-obligation estimate", "Fixed, itemised pricing", "Response within 24 hours"].map(t => (
                <div key={t} style={{ display: "flex", gap: 10, alignItems: "center", color: "var(--text-body)", fontSize: 15 }}>
                  <span style={{ width: 22, height: 22, borderRadius: 999, background: "var(--success-50)", color: "var(--success-500)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 13, fontWeight: 700 }}>✓</span>{t}
                </div>
              ))}
            </div>
          </div>
          <div style={{ background: "var(--surface-card)", border: "1px solid var(--border)", borderRadius: 20, padding: 28, boxShadow: "var(--shadow-md)" }}>
            {sent ? (
              <div style={{ textAlign: "center", padding: "40px 12px" }}>
                <div style={{ fontSize: 44 }}>✅</div>
                <h3 style={{ fontFamily: "var(--font-display)", fontSize: 24, color: "var(--text-strong)", margin: "12px 0 6px" }}>Thanks — request received!</h3>
                <p style={{ color: "var(--text-muted)", margin: 0 }}>We'll be in touch within one business day.</p>
              </div>
            ) : (
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
                <Field label="Full name" required><input style={inputStyle} placeholder="Your name" onFocus={focus} onBlur={blur} /></Field>
                <Field label="Phone" required><input style={inputStyle} placeholder="+91 …" onFocus={focus} onBlur={blur} /></Field>
                <div style={{ gridColumn: "1 / -1" }}><Field label="Project type" required>
                  <select style={{ ...inputStyle, appearance: "none" }} onFocus={focus} onBlur={blur}><option>Residential</option><option>Commercial</option><option>Renovation</option><option>Interior fit-out</option></select>
                </Field></div>
                <Field label="Budget range"><select style={{ ...inputStyle, appearance: "none" }} onFocus={focus} onBlur={blur}><option>Under ₹25L</option><option>₹25L – ₹1Cr</option><option>₹1Cr+</option></select></Field>
                <Field label="Timeline"><select style={{ ...inputStyle, appearance: "none" }} onFocus={focus} onBlur={blur}><option>0–3 months</option><option>3–6 months</option><option>6+ months</option></select></Field>
                <div style={{ gridColumn: "1 / -1" }}><Field label="Project details">
                  <textarea rows="4" style={{ ...inputStyle, height: "auto", padding: "12px 14px", resize: "vertical" }} placeholder="Scope, location and any specifics…" onFocus={focus} onBlur={blur} />
                </Field></div>
                <div style={{ gridColumn: "1 / -1" }}>
                  <Btn size="lg" style={{ width: "100%" }} onClick={() => setSent(true)}>Send request →</Btn>
                </div>
              </div>
            )}
          </div>
        </div>
      </Container>
    </section>
  );
}

/* ==================== APP SHELL ==================== */
function WebsiteApp() {
  const [route, setRoute] = React.useState("home");
  const go = (r) => { setRoute(r); document.getElementById("root").scrollTo?.(0, 0); window.scrollTo(0, 0); };
  const map = { home: Home, services: Services, projects: Projects, quote: Quote, about: Home, contact: Quote };
  const Screen = map[route] || Home;
  return (
    <div style={{ background: "var(--surface-page)" }}>
      <Header route={route} go={go} />
      <Screen go={go} />
      <Footer go={go} />
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<WebsiteApp />);
